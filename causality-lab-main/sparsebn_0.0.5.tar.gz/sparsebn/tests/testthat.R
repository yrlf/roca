library(testthat)
library(sparsebn)

test_check("sparsebn")
